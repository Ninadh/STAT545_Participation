

#'@title square the input
#'@param x Vector of numerics
#'@return The vector x squared
#'@export Add the square funciton to NAMESPACE
square <- function (x) x^2
